package com.example.Product_Service.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

@Data
public class ProductDTO {

    private Long product_id;
    private int seller_id;
    private String name;
    private String email;
    private String description;
    private String thumbnail;
    private Set<Long> productImages;
    private double price;
    private int quantity;
    private String category;
    private String subcategory1;
    private String subcategory2;
    private LocalDateTime createdAt;

}
